# 
# Kevin R Foster, the City College of New York, CUNY

# I know, everything is all caps so it's like some grannie did all the coding
# at bottom are variable descriptions

# this is how I loaded the BRFSS data but you don't have to - use next program


require(foreign)


dat1 <- read.xport("LLCP2022.XPT")
summary(dat1)

dat2 <- subset(dat1,select = c( X_STATE, SEXVAR,  GENHLTH, PHYSHLTH, MENTHLTH,  
  PRIMINSR, MEDCOST1, CHECKUP1, EXERANY2, SLEPTIM1, ADDEPEV3, MARITAL, 
  EDUCA, RENTHOM1, VETERAN3, EMPLOY1, CHILDREN, INCOME3, WEIGHT2, HEIGHT3, 
  SMOKE100, SMOKDAY2, ECIGNOW2, ALCDAY4, AVEDRNK3, DRNK3GE5, FLUSHOT7, HIVTST7,
  COVIDPOS, COVIDSMP, COVIDPRM, COVIDVA1, COVIDNU1, CIMEMLOS, CDHOUSE,
  CDASSIST, CDSOCIAL, CAREGIV1, CRGVREL4, ACEDEPRS, ACEDRINK, ACEDRUGS, 
  ACEPRISN, ACEDIVRC, ACEPUNCH, ACEHURT1, ACESWEAR, ACETOUCH, LSATISFY, 
  EMTSUPRT, SDHISOLT, FOODSTMP, SDHFOOD1, SDHSTRE1, MARIJAN1, FIREARM5, 
  BIRTHSEX, SOMALE, SOFEMALE, TRNSGNDR, HADSEX, PFPPRVN4, RRCLASS3, RRCOGNT2, 
  RRTREAT, X_METSTAT, X_URBSTAT, MSCODE, X_PHYS14D, X_MENT14D, X_HLTHPLN, 
  X_TOTINDA, X_PRACE2, X_HISPANC, X_AGEG5YR, X_BMI5, X_BMI5CAT, X_CHLDCNT))

summary(dat2)
save(dat2,file = "brfss2022.Rdata")
# later 
# load("brfss2022.Rdata")



require(plyr)
require(dplyr)
require(tidyverse)

load("brfss2022.Rdata")


dat2$X_STATE <- as.factor(dat2$X_STATE)
levels_orig <- levels(dat2$X_STATE) 
levels_n <- read.csv("X_STATE_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$X_STATE) <- levels_new$New_Level

dat2$SEXVAR <- as.factor(dat2$SEXVAR)
levels(dat2$SEXVAR) <- c("Male","Female")


# is.na(dat2$GENHLTH) <- which((dat2$GENHLTH == 7) | (dat2$GENHLTH == 9)) 
dat2$GENHLTH <- as.factor(dat2$GENHLTH)
levels_orig <- levels(dat2$GENHLTH) 
levels_n <- read.csv("GENHLTH_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$GENHLTH) <- levels_new$New_Level


is.na(dat2$PHYSHLTH) <- which((dat2$PHYSHLTH == 77) | (dat2$PHYSHLTH == 99)) 
dat2$PHYSHLTH[dat2$PHYSHLTH == 88] <- 0

is.na(dat2$MENTHLTH) <- which((dat2$MENTHLTH == 77) | (dat2$MENTHLTH == 99)) 
dat2$MENTHLTH[dat2$MENTHLTH == 88] <- 0

dat2$PRIMINSR <- as.factor(dat2$PRIMINSR)
levels_orig <- levels(dat2$PRIMINSR) 
levels_n <- read.csv("PRIMINSR_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$PRIMINSR) <- levels_new$New_Level


is.na(dat2$MEDCOST1) <- which((dat2$MEDCOST1 == 7) | (dat2$MEDCOST1 == 9) )
dat2$MEDCOST1 <- as.factor(dat2$MEDCOST1)
levels(dat2$MEDCOST1) <- c("Yes, needed to see a doctor but could not because you could not afford it, last 12 mo","No")


dat2$CHECKUP1 <- as.factor(dat2$CHECKUP1)
levels_orig <- levels(dat2$CHECKUP1) 
levels_n <- read.csv("CHECKUP1_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$CHECKUP1) <- levels_new$New_Level


is.na(dat2$EXERANY2) <- which((dat2$EXERANY2 == 7) | (dat2$EXERANY2 == 9) )
dat2$EXERANY2 <- as.factor(dat2$EXERANY2)
levels(dat2$EXERANY2) <- c("Yes exercised in past month","No")


is.na(dat2$SLEPTIM1) <- which((dat2$SLEPTIM1 == 77) | (dat2$SLEPTIM1 == 99)) 

is.na(dat2$ADDEPEV3) <- which((dat2$ADDEPEV3 == 7) | (dat2$ADDEPEV3 == 9) )
dat2$ADDEPEV3 <- as.factor(dat2$ADDEPEV3)
levels(dat2$ADDEPEV3) <- c("Yes ever told had depressive disorder","No")


dat2$MARITAL <- as.factor(dat2$MARITAL)
levels_orig <- levels(dat2$MARITAL) 
levels_n <- read.csv("MARITAL_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$MARITAL) <- levels_new$New_Level

dat2$EDUCA <- as.factor(dat2$EDUCA)
levels_orig <- levels(dat2$EDUCA) 
levels_n <- read.csv("EDUCA_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$EDUCA) <- levels_new$New_Level


is.na(dat2$RENTHOM1) <- which((dat2$RENTHOM1 == 7) | (dat2$RENTHOM1 == 9) ) 
dat2$RENTHOM1 <- as.factor(dat2$RENTHOM1)
levels(dat2$RENTHOM1) <- c("own home","rent","other")

is.na(dat2$VETERAN3) <- which((dat2$VETERAN3 == 7) | (dat2$VETERAN3 == 9) )
dat2$VETERAN3 <- as.factor(dat2$VETERAN3)
levels(dat2$VETERAN3) <- c("Yes a veteran","No")



is.na(dat2$EMPLOY1) <- which((dat2$EMPLOY1 == 9)) 
dat2$EMPLOY1 <- as.factor(dat2$EMPLOY1)
levels_orig <- levels(dat2$EMPLOY1) 
levels_n <- read.csv("EMPLOY1_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$EMPLOY1) <- levels_new$New_Level

dat2$CHILDREN[dat2$CHILDREN == 88] <- 0
is.na(dat2$CHILDREN) <- which( (dat2$CHILDREN == 99) )

dat2$INCOME3 <- as.factor(dat2$INCOME3)
levels_orig <- levels(dat2$INCOME3) 
levels_n <- read.csv("INCOME3_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$INCOME3) <- levels_new$New_Level

is.na(dat2$WEIGHT2) <- which(dat2$WEIGHT2 >= 7777) # fuck the metric system

is.na(dat2$HEIGHT3) <- which(dat2$HEIGHT3 >= 7777) # fuck the metric system
dat2$Height_inches <- 12*floor(dat2$HEIGHT3/100) + (dat2$HEIGHT3 %% (100*floor(dat2$HEIGHT3/100)))
# for HEIGHT3, 506 means 5'6"; 511 means 5'11"; etc

dat2$SMOKE100 <- as.factor(dat2$SMOKE100)
levels(dat2$SMOKE100) <- c("yes smoked at least 100 cigs in life","no","dont know not sure","refused")

dat2$SMOKDAY2 <- as.factor(dat2$SMOKDAY2)
levels_orig <- levels(dat2$SMOKDAY2) 
levels_n <- read.csv("SMOKDAY2_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$SMOKDAY2) <- levels_new$New_Level

dat2$ECIGNOW2 <- as.factor(dat2$ECIGNOW2)
levels_orig <- levels(dat2$ECIGNOW2) 
levels_n <- read.csv("ECIGNOW2_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$ECIGNOW2) <- levels_new$New_Level

dat2$ALCDAY4 <- as.factor(dat2$ALCDAY4)
levels_orig <- levels(dat2$ALCDAY4) 
levels_n <- read.csv("ALCDAY4_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$ALCDAY4) <- levels_new$New_Level

dat2$AVEDRNK3[dat2$AVEDRNK3 == 88] <- 0
is.na(dat2$AVEDRNK3) <- which( (dat2$AVEDRNK3 == 77) | (dat2$AVEDRNK3 == 99) )
# avg drinks per day in last 30

dat2$DRNK3GE5[dat2$DRNK3GE5 == 88] <- 0
is.na(dat2$DRNK3GE5) <- which( (dat2$DRNK3GE5 == 77) | (dat2$DRNK3GE5 == 99) )
# times in past month when binge drink

is.na(dat2$FLUSHOT7) <- which( (dat2$FLUSHOT7 == 7) | (dat2$FLUSHOT7 == 9) )
dat2$FLUSHOT7 <- as.factor(dat2$FLUSHOT7)
levels(dat2$FLUSHOT7) <- c("Yes got flu shot in last 12 mo","No")

is.na(dat2$HIVTST7) <- which((dat2$HIVTST7 == 7) | (dat2$HIVTST7 == 9) )
dat2$HIVTST7 <- as.factor(dat2$HIVTST7)
levels(dat2$HIVTST7) <- c("Yes had HIV test","No")

is.na(dat2$COVIDPOS) <- which((dat2$COVIDPOS == 7) | (dat2$COVIDPOS == 9) )
dat2$COVIDPOS <- as.factor(dat2$COVIDPOS)
levels(dat2$COVIDPOS) <- c("Yes had med prof tell positive test","No","tested positive at home wo med prof")

is.na(dat2$COVIDSMP) <- which((dat2$COVIDSMP == 7) | (dat2$COVIDSMP == 9) )
dat2$COVIDSMP <- as.factor(dat2$COVIDSMP)
levels(dat2$COVIDSMP) <- c("Yes had covid symptoms for more than 3 months","No")

dat2$COVIDPRM <- as.factor(dat2$COVIDPRM)
levels_orig <- levels(dat2$COVIDPRM) 
levels_n <- read.csv("COVIDPRM_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$COVIDPRM) <- levels_new$New_Level

is.na(dat2$COVIDVA1) <- which((dat2$COVIDVA1 == 7) | (dat2$COVIDVA1 == 9) )
dat2$COVIDVA1 <- as.factor(dat2$COVIDVA1)
levels(dat2$COVIDVA1) <- c("Yes had at least 1 covid vax","No")

is.na(dat2$COVIDNU1) <- which((dat2$COVIDNU1 == 7) | (dat2$COVIDNU1 == 9) )
dat2$COVIDNU1 <- as.factor(dat2$COVIDNU1)
levels(dat2$COVIDNU1) <- c("had 1 covid vax","2 covid vax","3 covid vax","4 covid vax")

is.na(dat2$CIMEMLOS) <- which((dat2$CIMEMLOS == 7) | (dat2$CIMEMLOS == 9) )
dat2$CIMEMLOS <- as.factor(dat2$CIMEMLOS)
levels(dat2$CIMEMLOS) <- c("experienced confusion memory loss in last 12 mo ","no")

dat2$CDHOUSE <- as.factor(dat2$CDHOUSE)
levels_orig <- levels(dat2$CDHOUSE) 
levels_n <- read.csv("CDHOUSE_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$CDHOUSE) <- levels_new$New_Level
# Q: During the past 12 months, as a result of confusion or memory loss, how often have you given up day-to-day household activities or chores you used to do, such as cooking, cleaning, taking medications, driving, or paying bills?

dat2$CDASSIST <- as.factor(dat2$CDASSIST)
levels_orig <- levels(dat2$CDASSIST) 
levels_n <- read.csv("CDASSIST_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$CDASSIST) <- levels_new$New_Level

dat2$CDSOCIAL <- as.factor(dat2$CDSOCIAL)
levels_orig <- levels(dat2$CDSOCIAL) 
levels_n <- read.csv("CDSOCIAL_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$CDSOCIAL) <- levels_new$New_Level

is.na(dat2$CAREGIV1) <- which((dat2$CAREGIV1 == 7) | (dat2$CAREGIV1 == 9) )
dat2$CAREGIV1 <- as.factor(dat2$CAREGIV1)
levels(dat2$CAREGIV1) <- c("provided care to family or friend with disability or health condition","no","caregiving recipient died in past 30 days")

dat2$CRGVREL4 <- as.factor(dat2$CRGVREL4)
levels_orig <- levels(dat2$CRGVREL4) 
levels_n <- read.csv("CRGVREL4_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$CRGVREL4) <- levels_new$New_Level

dat2$ACEDEPRS <- as.factor(dat2$ACEDEPRS)
levels(dat2$ACEDEPRS) <- c("Yes, Adverse Childhood Exper, lived with someone who was depressed, mentally ill, or suicidal","No","dont know not sure","refused")

dat2$ACEDRINK <- as.factor(dat2$ACEDRINK)
levels(dat2$ACEDRINK) <- c("Yes, Adverse Childhood Exper, lived with someone who was a problem drinker or alcoholic","No","dont know not sure","refused")

dat2$ACEDRUGS <- as.factor(dat2$ACEDRUGS)
levels(dat2$ACEDRUGS) <- c("Yes, Adverse Childhood Exper, lived with someone who used illegal street drugs or who abused prescription medications","No","dont know not sure","refused")

dat2$ACEPRISN <- as.factor(dat2$ACEPRISN)
levels(dat2$ACEPRISN) <- c("Yes, Adverse Childhood Exper, lived with someone who served time or was sentenced to serve time in a prison, jail, or other correctional facility","No","dont know not sure","refused")

dat2$ACEDIVRC <- as.factor(dat2$ACEDIVRC)
levels(dat2$ACEDIVRC) <- c("Yes, Adverse Childhood Exper, parents separated or divorced","No","dont know not sure","parents never married","refused")

dat2$ACEPUNCH <- as.factor(dat2$ACEPUNCH)
levels(dat2$ACEPUNCH) <- c("Adverse Childhood Exper, never: How often did your parents or adults in your home ever slap, hit, kick, punch or beat each other up","once","more than once","dont know not sure","refused")

dat2$ACEHURT1 <- as.factor(dat2$ACEHURT1)
levels(dat2$ACEHURT1) <- c("Adverse Childhood Exper, never: Not including spanking, (before age 18), how often did a parent or adult in your home ever hit, beat, kick, or physically hurt you in any way","once","more than once","dont know not sure","refused")

dat2$ACESWEAR <- as.factor(dat2$ACESWEAR)
levels(dat2$ACESWEAR) <- c("Adverse Childhood Exper, never: How often did a parent or adult in your home ever swear at you, insult you, or put you down","once","more than once","dont know not sure","refused")

dat2$ACETOUCH <- as.factor(dat2$ACETOUCH)
levels(dat2$ACETOUCH) <- c("Adverse Childhood Exper, never:  How often did anyone at least 5 years older than you or an adult, ever touch you sexually","once","more than once","dont know not sure","refused")

dat2$LSATISFY <- as.factor(dat2$LSATISFY)
levels_orig <- levels(dat2$LSATISFY) 
levels_n <- read.csv("LSATISFY_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$LSATISFY) <- levels_new$New_Level

dat2$EMTSUPRT <- as.factor(dat2$EMTSUPRT)
levels_orig <- levels(dat2$EMTSUPRT) 
levels_n <- read.csv("EMTSUPRT_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$EMTSUPRT) <- levels_new$New_Level

dat2$SDHISOLT <- as.factor(dat2$SDHISOLT)
levels_orig <- levels(dat2$SDHISOLT) 
levels_n <- read.csv("SDHISOLT_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$SDHISOLT) <- levels_new$New_Level

is.na(dat2$FOODSTMP) <- which((dat2$FOODSTMP == 7) | (dat2$FOODSTMP == 9) )
dat2$FOODSTMP <- as.factor(dat2$FOODSTMP)
levels(dat2$FOODSTMP) <- c("got food stamps SNAP","no")

dat2$SDHFOOD1 <- as.factor(dat2$SDHFOOD1)
levels_orig <- levels(dat2$SDHFOOD1) 
levels_n <- read.csv("SDHFOOD1_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$SDHFOOD1) <- levels_new$New_Level


dat2$SDHSTRE1 <- as.factor(dat2$SDHSTRE1)
levels_orig <- levels(dat2$SDHSTRE1) 
levels_n <- read.csv("SDHSTRE1_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$SDHSTRE1) <- levels_new$New_Level

dat2$MARIJAN1[dat2$MARIJAN1 == 88] <- 0
is.na(dat2$MARIJAN1) <- which( (dat2$MARIJAN1 == 77) | (dat2$MARIJAN1 == 99) )
# Q: During the past 30 days, on how many days did you use marijuana or cannabis?

is.na(dat2$FIREARM5) <- which((dat2$FIREARM5 == 7) | (dat2$FIREARM5 == 9) )
dat2$FIREARM5 <- as.factor(dat2$FIREARM5)
levels(dat2$FIREARM5) <- c("yes firearms in house","no")

is.na(dat2$BIRTHSEX) <- which((dat2$BIRTHSEX == 7) | (dat2$BIRTHSEX == 9) )
dat2$BIRTHSEX <- as.factor(dat2$BIRTHSEX)
levels(dat2$BIRTHSEX) <- c("male sex at birth","female sex at birth")

dat2$SOMALE <- as.factor(dat2$SOMALE)
levels_orig <- levels(dat2$SOMALE) 
levels_n <- read.csv("SOMALE_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$SOMALE) <- levels_new$New_Level

dat2$SOFEMALE <- as.factor(dat2$SOFEMALE)
levels_orig <- levels(dat2$SOFEMALE) 
levels_n <- read.csv("SOFEMALE_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$SOFEMALE) <- levels_new$New_Level

dat2$TRNSGNDR <- as.factor(dat2$TRNSGNDR)
levels_orig <- levels(dat2$TRNSGNDR) 
levels_n <- read.csv("TRNSGNDR_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$TRNSGNDR) <- levels_new$New_Level

dat2$HADSEX <- as.factor(dat2$HADSEX)
levels(dat2$HADSEX) <- c("yes had sex in last 6 mo","no","dont know not sure","refused")

dat2$PFPPRVN4 <- as.factor(dat2$PFPPRVN4)
levels(dat2$PFPPRVN4) <- c("last time had sex, did you or partner do anything to keep you from getting pregnant?","no","dont know not sure","refused")

dat2$RRCLASS3 <- as.factor(dat2$RRCLASS3)
levels_orig <- levels(dat2$RRCLASS3) 
levels_n <- read.csv("RRCLASS3_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$RRCLASS3) <- levels_new$New_Level

dat2$RRCOGNT2 <- as.factor(dat2$RRCOGNT2)
levels_orig <- levels(dat2$RRCOGNT2) 
levels_n <- read.csv("RRCOGNT2_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$RRCOGNT2) <- levels_new$New_Level

dat2$RRTREAT <- as.factor(dat2$RRTREAT)
levels_orig <- levels(dat2$RRTREAT) 
levels_n <- read.csv("RRTREAT_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$RRTREAT) <- levels_new$New_Level

dat2$X_METSTAT <- as.factor(dat2$X_METSTAT)
levels(dat2$X_METSTAT) <- c("Metropolitan counties","nonmetropolitan counties")

dat2$X_URBSTAT <- as.factor(dat2$X_URBSTAT)
levels(dat2$X_URBSTAT) <- c("urban counties","rural counties")

dat2$X_PHYS14D <- as.factor(dat2$X_PHYS14D)
levels(dat2$X_PHYS14D) <- c("Zero days when physical health not good","1-13 days","14+ days","dont know refused missing")

dat2$X_MENT14D <- as.factor(dat2$X_MENT14D)
levels(dat2$X_MENT14D) <- c("Zero days when mental health not good","1-13 days","14+ days","dont know refused missing")

dat2$X_HLTHPLN <- as.factor(dat2$X_HLTHPLN)
levels(dat2$X_HLTHPLN) <- c("adults have some form of insurance","no","dont know refused missing")

dat2$X_TOTINDA <- as.factor(dat2$X_TOTINDA)
levels(dat2$X_TOTINDA) <- c("physical activity or exercise in last 30 days","no","dont know refused missing")

dat2$X_PRACE2 <- as.factor(dat2$X_PRACE2)
levels_orig <- levels(dat2$X_PRACE2) 
levels_n <- read.csv("X_PRACE2_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$X_PRACE2) <- levels_new$New_Level

dat2$X_HISPANC <- as.factor(dat2$X_HISPANC)
levels(dat2$X_HISPANC) <- c("yes Hispanic","no","dont know refused missing")

dat2$X_AGEG5YR <- as.factor(dat2$X_AGEG5YR)
levels_orig <- levels(dat2$X_AGEG5YR) 
levels_n <- read.csv("X_AGEG5YR_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$X_AGEG5YR) <- levels_new$New_Level

dat2$X_BMI5 <- dat2$X_BMI5/100 # since 2 implied decimals



dat2$X_BMI5CAT <- as.factor(dat2$X_BMI5CAT)
levels_orig <- levels(dat2$X_BMI5CAT) 
levels_n <- read.csv("X_BMI5CAT_levels.csv")
levels_new <- join(data.frame(levels_orig),data.frame(levels_n))
levels(dat2$X_BMI5CAT) <- levels_new$New_Level

is.na(dat2$X_CHLDCNT) <- which((dat2$X_CHLDCNT == 9))
dat2$X_CHLDCNT <- (dat2$X_CHLDCNT - 1) # and 5 or more is topcoded

dat2$MSCODE <- as.factor(dat2$MSCODE)
levels(dat2$MSCODE) <- c("in central city","in county containing central city","in suburb near city","outside MSA")

#brfss22 <- dat2

brfss22 <- subset(dat2,select = c(X_STATE, X_METSTAT, X_URBSTAT, MSCODE,
                                  CHILDREN, MARITAL, EDUCA, VETERAN3, X_PRACE2, X_HISPANC, X_AGEG5YR,
                                  RENTHOM1, EMPLOY1, INCOME3, FOODSTMP, SDHFOOD1, 
                                  SEXVAR, BIRTHSEX, SOMALE, SOFEMALE, TRNSGNDR, HADSEX, 
                                  GENHLTH, PHYSHLTH, MENTHLTH, LSATISFY, EMTSUPRT, SDHISOLT, SDHSTRE1, ADDEPEV3, 
                                  PRIMINSR, CHECKUP1, FLUSHOT7, COVIDPOS, COVIDSMP, COVIDPRM, COVIDVA1, COVIDNU1,
                                  EXERANY2, SLEPTIM1, Height_inches, WEIGHT2, X_BMI5, X_BMI5CAT,
                                  SMOKE100, SMOKDAY2, ECIGNOW2, ALCDAY4,  AVEDRNK3, DRNK3GE5, MARIJAN1, FIREARM5, 
                                  ACEDEPRS, ACEDRINK, ACEDRUGS, ACEPRISN, ACEDIVRC, ACEPUNCH, ACEHURT1, ACESWEAR, ACETOUCH,           
                                  CIMEMLOS, CDHOUSE, CDASSIST, CDSOCIAL, CAREGIV1, CRGVREL4 ))


save(brfss22, file = "BRFSS2022_rev.RData")


load("BRFSS2022_rev.RData")

